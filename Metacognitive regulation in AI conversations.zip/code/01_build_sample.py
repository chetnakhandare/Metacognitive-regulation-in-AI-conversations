"""Step 1 - build the stratified CMS sample from WildChat-1M and LMSYS-Chat-1M (Section 4.2, Table 2).

LMSYS-Chat-1M is gated: accept its licence on Hugging Face and run 'huggingface-cli login'.
Raw conversations are written only to data/ and must not be redistributed (Section 8).
"""
import argparse
import json
import random
import re
from collections import Counter, defaultdict

import pandas as pd
from datasets import load_dataset
from datasketch import MinHash, MinHashLSH
from transformers import pipeline

SEED = 2026
DOMAINS = {"coding": "computer programming or debugging code",
           "academic": "academic study, homework or exam preparation",
           "analytical": "mathematical, statistical or analytical problem solving",
           "other": "creative writing, chit-chat or something else"}
EXCLUDE = re.compile(r"midjourney|/imagine|\bjailbreak|\bDAN\b|role-?play|pretend (?:you are|to be)|\bact as\b|"
                     r"write (?:a|me a) (?:story|poem|song|novel)|fan ?fic", re.I)
PER_CELL, POOL_FACTOR, USER_CAP = 80, 5, 3      # 3 domains x 2 corpora x 80 = 480
STAGE = Counter()


def wildchat(limit=None):
    for i, r in enumerate(load_dataset("allenai/WildChat-1M", split="train", streaming=True)):
        if limit and i >= limit:
            break
        STAGE["wildchat_0_all"] += 1
        if r["language"] != "English": continue
        STAGE["wildchat_1_english"] += 1
        if r["turn"] < 4: continue
        STAGE["wildchat_2_4turns"] += 1
        if r["toxic"] or r["redacted"]: continue
        STAGE["wildchat_3_clean"] += 1
        yield {"conv_id": r["conversation_hash"], "source": "wildchat", "model": r["model"],
               "user_key": r["conversation"][0].get("hashed_ip"),
               "messages": [(m["role"], m["content"]) for m in r["conversation"]]}


def lmsys(limit=None):
    for i, r in enumerate(load_dataset("lmsys/lmsys-chat-1m", split="train", streaming=True)):
        if limit and i >= limit:
            break
        STAGE["lmsys_0_all"] += 1
        if r["language"] != "English": continue
        STAGE["lmsys_1_english"] += 1
        if r["turn"] < 4: continue
        STAGE["lmsys_2_4turns"] += 1
        if r["redacted"] or any(m.get("flagged") for m in r["openai_moderation"]): continue
        STAGE["lmsys_3_clean"] += 1
        yield {"conv_id": r["conversation_id"], "source": "lmsys", "model": r["model"],
               "user_key": None,       # LMSYS-Chat-1M releases no user identifier
               "messages": [(m["role"], m["content"]) for m in r["conversation"]]}


def first_user(c):
    return next(t for role, t in c["messages"] if role == "user")


def minhash(text, k=5):
    toks, m = re.findall(r"\w+", text.lower()), MinHash(num_perm=128)
    for i in range(max(1, len(toks) - k + 1)):
        m.update(" ".join(toks[i:i + k]).encode())
    return m


def main(a):
    rng = random.Random(SEED)
    cands = []
    for c in list(wildchat(a.limit)) + list(lmsys(a.limit)):
        if EXCLUDE.search(first_user(c)[:2000]): continue
        STAGE[c["source"] + "_4_task_filter"] += 1
        cands.append(c)

    lsh, dedup = MinHashLSH(threshold=0.8, num_perm=128), []
    for c in cands:
        m = minhash(first_user(c)[:2000])
        if lsh.query(m): continue
        lsh.insert(c["conv_id"], m)
        dedup.append(c)
        STAGE[c["source"] + "_6_dedup"] += 1

    rng.shuffle(dedup)
    per_user, capped = defaultdict(int), []
    for c in dedup:
        if c["user_key"]:
            per_user[c["user_key"]] += 1
            if per_user[c["user_key"]] > USER_CAP: continue
        capped.append(c)
        STAGE[c["source"] + "_7_user_cap"] += 1

    clf = pipeline("zero-shot-classification", model="facebook/bart-large-mnli", device=a.device)
    labels, inv = list(DOMAINS.values()), {v: k for k, v in DOMAINS.items()}
    pools, need = defaultdict(list), PER_CELL * POOL_FACTOR
    cells = [(d, s) for d in ("coding", "academic", "analytical") for s in ("wildchat", "lmsys")]
    for i in range(0, len(capped), 32):
        batch = capped[i:i + 32]
        for c, o in zip(batch, clf([first_user(c)[:1000] for c in batch], candidate_labels=labels)):
            dom = inv[o["labels"][0]]
            if dom != "other" and o["scores"][0] >= 0.5:
                c["domain"] = dom
                pools[(dom, c["source"])].append(c)
        if all(len(pools[k]) >= need for k in cells):
            break
    for (d, s), p in pools.items():
        STAGE[f"{s}_5_domain_pool_{d}"] = len(p)

    sample = []
    for (dom, src) in cells:
        pool = pools[(dom, src)]
        if src == "wildchat":   # balance GPT-4 vs GPT-3.5 within WildChat
            g4 = [c for c in pool if "gpt-4" in c["model"]]
            g3 = [c for c in pool if "gpt-4" not in c["model"]]
            take4 = rng.sample(g4, min(PER_CELL // 2, len(g4)))
            sample += take4 + rng.sample(g3, min(PER_CELL - len(take4), len(g3)))
        else:
            sample += rng.sample(pool, min(PER_CELL, len(pool)))
    STAGE["8_final_sample"] = len(sample)

    rows = []
    for c in sample:
        msgs, k = c["messages"], 0
        for j, (role, text) in enumerate(msgs):
            if role != "user": continue
            k += 1
            prev_ai = msgs[j - 1][1] if j > 0 and msgs[j - 1][0] == "assistant" else ""
            next_ai = msgs[j + 1][1] if j + 1 < len(msgs) and msgs[j + 1][0] == "assistant" else ""
            rows.append({"conv_id": c["conv_id"], "source": c["source"], "model": c["model"],
                         "domain": c["domain"], "turn_idx": k, "user_text": text,
                         "prev_ai_text": prev_ai, "next_ai_text": next_ai})
    pd.DataFrame(rows).to_parquet(a.out, index=False)
    json.dump(dict(sorted(STAGE.items())), open(a.out.replace(".parquet", "_stages.json"), "w"), indent=2)
    print(json.dumps(dict(sorted(STAGE.items())), indent=2))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="data/turns.parquet")
    p.add_argument("--limit", type=int, default=None, help="debug: stop after N rows per corpus")
    p.add_argument("--device", type=int, default=-1, help="-1 = CPU, 0 = first GPU")
    main(p.parse_args())
