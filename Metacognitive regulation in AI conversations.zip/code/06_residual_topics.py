"""Step 6 - BERTopic on unclassified user turns to surface markers the codebook may miss (Section 4.4)."""
import argparse

import pandas as pd
from bertopic import BERTopic


def main(a):
    turns = pd.read_parquet(a.turns)[["conv_id", "turn_idx", "user_text"]]
    lab = pd.read_csv(a.labels)[["conv_id", "turn_idx", "subcode"]]
    df = turns.merge(lab, on=["conv_id", "turn_idx"])
    docs = df.loc[df.subcode.isin(["UNC", "N1"]), "user_text"].astype(str).str[:1000].tolist()
    model = BERTopic(min_topic_size=a.min_topic_size, verbose=True)
    model.fit_transform(docs)
    model.get_topic_info().to_csv(a.out, index=False)
    print(model.get_topic_info().head(20))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--turns", default="data/turns.parquet")
    p.add_argument("--labels", default="data/labels_model.csv")
    p.add_argument("--min-topic-size", type=int, default=15)
    p.add_argument("--out", default="results/residual_topics.csv")
    main(p.parse_args())
