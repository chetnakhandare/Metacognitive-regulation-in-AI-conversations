"""Step 3 - inter-rater reliability (Krippendorff's alpha) and disagreement export for adjudication."""
import argparse

import krippendorff
import numpy as np
import pandas as pd


def alpha(a, b):
    cats = {c: i for i, c in enumerate(sorted(set(a) | set(b)))}
    data = np.array([[cats[x] for x in a], [cats[x] for x in b]], dtype=float)
    return krippendorff.alpha(reliability_data=data, level_of_measurement="nominal")


def main(a):
    m = pd.read_csv(a.coder_a).merge(pd.read_csv(a.coder_b), on=["conv_id", "turn_idx"], suffixes=("_a", "_b"))
    sa, sb = m["subcode_a"].astype(str).str.strip(), m["subcode_b"].astype(str).str.strip()
    print(f"turns: {len(m)}  conversations: {m.conv_id.nunique()}")
    print(f"alpha top-level : {alpha(sa.str[0], sb.str[0]):.3f}")
    print(f"alpha sub-code  : {alpha(sa, sb):.3f}")
    rows = []
    for code in sorted(set(sa) | set(sb)):   # per-code agreement (code vs. not-code)
        x, y = (sa == code).astype(int), (sb == code).astype(int)
        if x.sum() + y.sum() >= 5:
            rows.append({"code": code, "n_a": x.sum(), "n_b": y.sum(), "alpha": alpha(x, y)})
    print(pd.DataFrame(rows).round(3).to_string(index=False))
    m[sa != sb].to_csv(a.disagreements, index=False)
    print(f"disagreements -> {a.disagreements}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--coder-a", required=True)
    p.add_argument("--coder-b", required=True)
    p.add_argument("--disagreements", default="data/disagreements.csv")
    main(p.parse_args())
