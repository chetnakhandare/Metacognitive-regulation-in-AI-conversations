"""Step 5 - sequence and trajectory analysis (Sections 4.5.1-4.5.5).

Input: turn-level labels (conv_id, turn_idx, domain, source, model, state, subcode, ai_*).
Output: results/summary.json, CSV tables and figures.
"""
import argparse
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from lifelines import CoxPHFitter, KaplanMeierFitter
from prefixspan import PrefixSpan
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform
from sklearn.metrics import silhouette_score

S = ["M", "C", "O", "N"]
IDX = {s: i for i, s in enumerate(S)}
REG = {"M", "C"}
AI_COLS = ["ai_visible_failure", "ai_self_contradiction", "ai_hedging", "ai_refusal", "ai_self_verify", "ai_log_len"]
RNG = np.random.default_rng(2026)


def load(path):
    df = pd.read_csv(path).sort_values(["conv_id", "turn_idx"])
    g = df.groupby("conv_id", sort=False)
    return df, g["state"].apply(list), g["subcode"].apply(list), g[["domain", "source", "model"]].first()


# ---------- 4.5.1 transition structure ----------
def counts(seqs, order=1):
    C = np.zeros((len(S),) * (order + 1))
    for s in seqs:
        x = [IDX[v] for v in s]
        for t in range(order, len(x)):
            C[tuple(x[t - order:t + 1])] += 1
    return C


def probs(C):
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.nan_to_num(C / C.sum(-1, keepdims=True))


def bootstrap_ci(seqs, B=2000, level=0.95):
    seqs, n = list(seqs), len(seqs)
    draws = np.stack([probs(counts([seqs[i] for i in RNG.integers(0, n, n)])) for _ in range(B)])
    q = (1 - level) / 2
    return np.quantile(draws, q, 0), np.quantile(draws, 1 - q, 0)


def loglik(C):
    P, m = probs(C), C > 0
    return float((C[m] * np.log(P[m])).sum())


def order_bic(seqs):
    """First- vs second-order Markov fit, estimated on the same target transitions (t >= 3)."""
    K = len(S)
    c2 = counts([s for s in seqs if len(s) >= 3], order=2)
    c1, n = c2.sum(0), c2.sum()
    out = {}
    for name, C, k in [("first", c1, K * (K - 1)), ("second", c2, K * K * (K - 1))]:
        ll = loglik(C)
        out[name] = {"loglik": ll, "params": k, "bic": -2 * ll + k * np.log(n)}
    out["delta_bic_second_minus_first"] = out["second"]["bic"] - out["first"]["bic"]
    return out


def lag_sequential(C):
    """Adjusted residuals and Yule's Q for lag-1 transitions (Bakeman and Quera 2011)."""
    N, r, c = C.sum(), C.sum(1, keepdims=True), C.sum(0, keepdims=True)
    E = r @ c / N
    z = (C - E) / np.sqrt(E * (1 - r / N) * (1 - c / N))
    a, b, cc = C, r - C, c - C
    d = N - a - b - cc
    with np.errstate(invalid="ignore", divide="ignore"):
        Q = (a * d - b * cc) / (a * d + b * cc)
    return z, Q


def transition_mnlogit(df):
    """Next state ~ previous state + domain + corpus, conversation-clustered SEs."""
    d = df.copy()
    d["prev"] = d.groupby("conv_id")["state"].shift()
    d = d.dropna(subset=["prev"]).reset_index(drop=True)
    d["y"] = d["state"].map(IDX)
    groups = pd.factorize(d["conv_id"])[0]
    return smf.mnlogit("y ~ C(prev, Treatment('O')) + C(domain) + C(source)", d).fit(
        disp=False, cov_type="cluster", cov_kwds={"groups": groups})


# ---------- 4.5.2 lock-in: survival to first regulatory turn ----------
def survival_table(seqs, meta):
    rows = []
    for cid, s in seqs.items():
        if len(s) < 4:
            continue
        head, later = s[:3], s[3:]
        group = ("early_offloading" if sum(v == "O" for v in head) >= 2
                 else "early_engaged" if any(v in REG for v in head) else "other")
        hit = next((i for i, v in enumerate(later) if v in REG), None)
        rows.append({"conv_id": cid, "group": group,
                     "duration": hit + 1 if hit is not None else len(later),
                     "event": int(hit is not None),
                     "domain": meta.loc[cid, "domain"], "source": meta.loc[cid, "source"]})
    return pd.DataFrame(rows)


# ---------- 4.5.3 sequential pattern mining ----------
def frequent_patterns(subs, minsup=0.05, minlen=2, maxlen=4):
    db = [list(s) for s in subs]
    ps = PrefixSpan(db)
    ps.minlen, ps.maxlen = minlen, maxlen
    k = max(2, int(np.ceil(minsup * len(db))))
    rows = [{"pattern": " -> ".join(p), "n": n, "support": n / len(db)} for n, p in ps.frequent(k)]
    return pd.DataFrame(rows, columns=["pattern", "n", "support"]).sort_values("support", ascending=False)


# ---------- 4.5.4 optimal matching + Ward clustering ----------
def substitution_costs(P):
    """TraMineR 'TRATE' costs: 2 - p(j|i) - p(i|j)."""
    sc = 2 - P - P.T
    np.fill_diagonal(sc, 0)
    return sc.tolist()


def om_distance(a, b, sc, indel=1.0):
    prev = [j * indel for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        cur = [i * indel] + [0.0] * len(b)
        ai = sc[a[i - 1]]
        for j in range(1, len(b) + 1):
            cur[j] = min(prev[j] + indel, cur[j - 1] + indel, prev[j - 1] + ai[b[j - 1]])
        prev = cur
    return prev[-1]


def om_matrix(seqs, sc, max_len=30):
    X = [[IDX[v] for v in s[:max_len]] for s in seqs]
    n = len(X)
    D = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            D[i, j] = D[j, i] = om_distance(X[i], X[j], sc)
    return D


def cluster(D, kmin=2, kmax=8):
    Z = linkage(squareform(D, checks=False), method="ward")
    sil = {k: float(silhouette_score(D, fcluster(Z, k, "maxclust"), metric="precomputed")) for k in range(kmin, kmax + 1)}
    k = max(sil, key=sil.get)
    return fcluster(Z, k, "maxclust"), sil


def regulation_profile(seqs, labels, T=12):
    rows = []
    for k in sorted(set(labels)):
        members = [s for s, l in zip(seqs, labels) if l == k]
        for t in range(T):
            at = [s[t] in REG for s in members if len(s) > t]
            rows.append({"cluster": k, "turn": t + 1, "share_regulation": np.mean(at) if at else np.nan,
                         "n": len(at), "cluster_size": len(members)})
    return pd.DataFrame(rows)


# ---------- 4.5.5 predictors of recovery from offloading ----------
def recovery_model(df):
    cols = [c for c in AI_COLS if c in df.columns]
    d = df.copy()
    d["next_state"] = d.groupby("conv_id")["state"].shift(-1)
    d = d[(d["state"] == "O") & d["next_state"].notna()].copy()
    d["y"] = d["next_state"].isin(REG).astype(int)
    f = "y ~ " + " + ".join(cols + ["turn_idx", "C(domain)", "C(source)"])
    res = smf.gee(f, groups="conv_id", data=d, family=sm.families.Binomial(),
                  cov_struct=sm.cov_struct.Exchangeable()).fit()
    ci = res.conf_int()
    return res, pd.DataFrame({"OR": np.exp(res.params), "lo": np.exp(ci[0]), "hi": np.exp(ci[1]), "p": res.pvalues})


# ---------- figures ----------
def plot_heatmap(P, path):
    fig, ax = plt.subplots(figsize=(5, 4.4))
    ax.imshow(P, cmap="Blues", vmin=0, vmax=max(0.75, P.max()))
    ax.set_xticks(range(4), S)
    ax.set_yticks(range(4), S)
    ax.set_xlabel("State at turn t+1")
    ax.set_ylabel("State at turn t")
    for i in range(4):
        for j in range(4):
            ax.text(j, i, f"{P[i, j]:.2f}", ha="center", va="center", color="white" if P[i, j] > 0.45 else "black")
    fig.tight_layout(); fig.savefig(path, dpi=300); plt.close(fig)


def plot_km(sv, path):
    fig, ax = plt.subplots(figsize=(6, 4))
    for g, lab in [("early_engaged", "Early-engaged opening"), ("early_offloading", "Early-offloading opening")]:
        d = sv[sv.group == g]
        if len(d):
            KaplanMeierFitter(label=lab).fit(d.duration, d.event).plot_survival_function(ax=ax, show_censors=True)
    ax.set_xlabel("User turns after turn 3"); ax.set_ylabel("Proportion not yet regulated")
    fig.tight_layout(); fig.savefig(path, dpi=300); plt.close(fig)


def plot_profiles(prof, path):
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for k, g in prof.groupby("cluster"):
        ax.plot(g.turn, g.share_regulation, marker="o", label=f"Cluster {k} (n={g.cluster_size.iloc[0]})")
    ax.set_xlabel("User turn index"); ax.set_ylabel("Share of turns coded M or C"); ax.set_ylim(0, 1); ax.legend()
    fig.tight_layout(); fig.savefig(path, dpi=300); plt.close(fig)


def main(a):
    os.makedirs(a.out, exist_ok=True)
    df, seqs, subs, meta = load(a.labels)
    summary = {"n_conversations": len(seqs), "n_turns": len(df),
               "state_share": df["state"].value_counts(normalize=True).round(4).to_dict()}

    C = counts(seqs); P = probs(C); lo, hi = bootstrap_ci(seqs, B=a.boot)
    for name, M in [("transition_P", P), ("transition_lo", lo), ("transition_hi", hi)]:
        pd.DataFrame(M, S, S).to_csv(f"{a.out}/{name}.csv")
    z, Q = lag_sequential(C)
    pd.DataFrame(z, S, S).to_csv(f"{a.out}/lag_adjusted_residuals.csv")
    pd.DataFrame(Q, S, S).to_csv(f"{a.out}/lag_yules_q.csv")
    o = IDX["O"]
    summary["H1"] = {"P_OO": P[o, o], "P_OO_CI": [lo[o, o], hi[o, o]],
                     "P_O_to_MC": P[o, IDX["M"]] + P[o, IDX["C"]],
                     "self_transitions": dict(zip(S, np.diag(P).round(4)))}
    summary["markov_order"] = order_bic(seqs)
    try:
        summary["mnlogit_aic"] = transition_mnlogit(df).aic
    except Exception as e:  # sparse cells can prevent convergence
        summary["mnlogit_error"] = str(e)

    sv = survival_table(seqs, meta)
    two = sv[sv.group.isin(["early_offloading", "early_engaged"])].copy()
    two["early_offloading"] = (two.group == "early_offloading").astype(int)
    cph = CoxPHFitter().fit(two[["duration", "event", "early_offloading", "domain", "source"]],
                            "duration", "event", formula="early_offloading + domain + source")
    summary["H2_cox"] = cph.summary.loc["early_offloading",
                                        ["exp(coef)", "exp(coef) lower 95%", "exp(coef) upper 95%", "p"]].to_dict()
    summary["never_regulated_after_early_offloading"] = 1 - two.loc[two.early_offloading == 1, "event"].mean()
    sv.to_csv(f"{a.out}/survival_table.csv", index=False)

    frequent_patterns(subs, a.minsup).to_csv(f"{a.out}/patterns_all.csv", index=False)
    for dom in meta.domain.unique():
        ids = meta.index[meta.domain == dom]
        frequent_patterns(subs.loc[ids], a.minsup).to_csv(f"{a.out}/patterns_{dom}.csv", index=False)
    pd.crosstab(df.domain, df.subcode, normalize="index").round(4).to_csv(f"{a.out}/subcode_by_domain.csv")  # H4

    D = om_matrix(list(seqs), substitution_costs(P))
    labels, sil = cluster(D)
    summary["clusters"] = {"k": int(labels.max()), "silhouette": sil}
    pd.DataFrame({"conv_id": seqs.index, "cluster": labels}).join(meta, on="conv_id").to_csv(f"{a.out}/clusters.csv", index=False)
    prof = regulation_profile(list(seqs), labels)
    prof.to_csv(f"{a.out}/cluster_profiles.csv", index=False)

    try:
        res, ors = recovery_model(df)
        ors.round(4).to_csv(f"{a.out}/recovery_odds_ratios.csv")
        summary["H3_H5_recovery_OR"] = ors["OR"].round(3).to_dict()
    except Exception as e:
        summary["recovery_error"] = str(e)

    plot_heatmap(P, f"{a.out}/fig_transition_heatmap.png")
    plot_km(sv, f"{a.out}/fig_km_first_regulation.png")
    plot_profiles(prof, f"{a.out}/fig_trajectory_archetypes.png")
    json.dump(summary, open(f"{a.out}/summary.json", "w"), indent=2, default=float)
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--labels", required=True)
    p.add_argument("--out", default="results")
    p.add_argument("--boot", type=int, default=2000)
    p.add_argument("--minsup", type=float, default=0.05)
    main(p.parse_args())
