"""Step 2 - lexicon coding of every user turn + assistant-turn features; optional gold annotation sheet."""
import argparse

import pandas as pd

from cms.lexicon import ai_features, code_turn, primary_subcode, reduce_state


def main(a):
    df = pd.read_parquet(a.turns)
    codes = df["user_text"].map(code_turn)
    df["codes"] = codes.map(lambda s: "|".join(sorted(s)))
    df["state"] = codes.map(reduce_state)
    df["subcode"] = codes.map(primary_subcode)
    feats = pd.DataFrame(df["next_ai_text"].map(ai_features).tolist(), index=df.index).add_prefix("ai_")
    out = pd.concat([df, feats], axis=1).drop(columns=["user_text", "prev_ai_text", "next_ai_text"])
    out.to_csv(a.out, index=False)
    print(out["state"].value_counts(normalize=True).round(3))

    if a.gold_sheet:   # stratified gold subset, blind to lexicon output, for two independent coders
        convs = df.drop_duplicates("conv_id")
        per = max(1, a.gold_sheet // convs.groupby(["domain", "source"]).ngroups)
        ids = convs.groupby(["domain", "source"], group_keys=False).apply(
            lambda g: g.sample(min(per, len(g)), random_state=2026))["conv_id"]
        sheet = df[df.conv_id.isin(ids)][["conv_id", "turn_idx", "prev_ai_text", "user_text", "next_ai_text"]].copy()
        for col in ["subcode", "secondary_codes", "confidence_1to3", "ai_visible_failure", "ai_self_contradiction", "notes"]:
            sheet[col] = ""
        sheet.sort_values(["conv_id", "turn_idx"]).to_csv(a.gold_out, index=False)
        print(f"gold sheet: {sheet.conv_id.nunique()} conversations, {len(sheet)} turns -> {a.gold_out}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--turns", default="data/turns.parquet")
    p.add_argument("--out", default="data/labels_lexicon.csv")
    p.add_argument("--gold-sheet", type=int, default=0, help="number of conversations to export for gold coding")
    p.add_argument("--gold-out", default="data/gold_sheet.csv")
    main(p.parse_args())
