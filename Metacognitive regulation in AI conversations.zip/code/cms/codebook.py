"""CMS codebook (Table 1) — labels and decision rules used by the LLM annotator."""

CODEBOOK = {
    "M1": ("Comprehension check", "Seeks clarification of a specific element of the AI output. Generic 'explain more' with no target is O3."),
    "M2": ("Error detection", "Identifies and characterises a specific fault in the output; must locate the trouble source."),
    "M3": ("Contradiction / doubt", "Flags inconsistency with prior turns, external knowledge or expectation, or expresses calibrated doubt."),
    "M4": ("Verification request", "Asks the AI to justify, source, check or state confidence in a claim."),
    "M5": ("Assumption probing", "Questions an assumption, premise or default the AI adopted."),
    "C1": ("Strategy shift", "Redirects the problem-solving approach."),
    "C2": ("Scaffold request", "Asks the AI to support the user's own thinking rather than supply the answer."),
    "C3": ("Reframing / constraints", "Reformulates the problem or adds substantive constraints derived from evaluation."),
    "C4": ("Own attempt / self-explanation", "Contributes the user's own solution, reasoning or explanation for evaluation."),
    "C5": ("Audit & test", "Requests or proposes a systematic check: tests, edge cases, comparison or derivation."),
    "C6": ("Goal re-specification", "Revises the goal or success criteria after reflecting on progress."),
    "O1": ("Whole-task delegation", "Requests a complete artefact the user will not co-construct."),
    "O2": ("Zero-friction continuation", "Minimal continuation signal with no evaluative content."),
    "O3": ("Surface revision", "Changes length, tone or format without an evaluation-grounded rationale."),
    "O4": ("Outsourced repair", "Signals failure without diagnosis and delegates the fix, incl. pasting a raw error."),
    "O5": ("Unverified acceptance", "Accepts output with no observable check, often followed by a new request."),
    "N1": ("Context provision", "Supplies information the task requires, without evaluation."),
    "N2": ("New task / topic shift", "Starts an unrelated request."),
    "N3": ("Social / phatic", "Greetings, thanks or rapport with no task content."),
}
