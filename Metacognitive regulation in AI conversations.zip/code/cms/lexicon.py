"""Conversational Metacognitive Signatures (CMS): lexicon-based turn coder.

High-precision baseline for the codebook in Table 1. Each sub-code is a list of
regular expressions applied to the user-authored prose of a turn (code blocks
and stack traces removed). A turn may match several sub-codes (multi-label);
reduce_state() applies the C > M > O > N precedence rule (Section 3.3).
"""
import math
import re

TOP = {"M": "Monitoring", "C": "Control", "O": "Offloading", "N": "Non-metacognitive"}
PRECEDENCE = ["C", "M", "O", "N"]

_P = {
    "M1": [r"\bwhat do(?:es)? (?:you|it|that|this) mean\b", r"\bwhat is meant by\b",
           r"\bi (?:don'?t|do not) (?:understand|get) (?:why|how|what|the|this|that)\b",
           r"\bwhich (?:part|line|variable|step|one)\b[^.?!]*\?", r"\b(?:can|could) you clarify\b",
           r"\bwhat'?s the difference between\b"],
    "M2": [r"\b(?:line|step) \d+\b[^.]*\b(?:wrong|incorrect|error|fails?|bug|missing)\b",
           r"\b(?:returns?|gives?|outputs?|prints?) [^.]{1,60}\b(?:instead of|but (?:it )?should)\b",
           r"\byou (?:forgot|missed|counted|skipped|dropped|swapped)\b",
           r"\b(?:is|seems|looks) (?:wrong|incorrect|off) because\b", r"\boff[- ]by[- ]one\b",
           r"\bthe (?:bug|problem|issue|error) is (?:that|in|with)\b", r"\bshould be [^.]{1,40} not\b"],
    "M3": [r"\b(?:that|this|it) contradicts\b", r"\b(?:but|earlier) you said\b",
           r"\bi don'?t think (?:that'?s|this is|it'?s|that is) (?:right|correct|true)\b",
           r"\b(?:that|this|it) (?:doesn'?t|does not) (?:make sense|add up)\b",
           r"\binconsistent\b", r"\bthat'?s not what\b"],
    "M4": [r"\bare you (?:sure|certain)\b", r"\bhow (?:sure|confident) are you\b",
           r"\b(?:can|could) you (?:verify|double[- ]check|confirm|fact[- ]check)\b",
           r"\b(?:what'?s|what is|give me) (?:the|your) sources?\b",
           r"\bis (?:that|this|it) (?:true|correct|accurate|right)\?", r"\bprove (?:it|that|this)\b"],
    "M5": [r"\bwhy (?:did|do|would) you (?:assume|use|choose|pick|treat)\b",
           r"\bare (?:we|you) (?:assuming|treating)\b", r"\bwhat if (?:the|we|it|there)\b",
           r"\bassum(?:e|es|ed|ing|ption)\b[^.]*\?"],
    "C1": [r"\b(?:let'?s|can we|could we|try) [^.]{0,40}\b(?:step[- ]by[- ]step|differently|another way|from scratch)\b",
           r"\b(?:a different|another|an alternative) (?:approach|method|way|strategy)\b",
           r"\binstead of [^.]{1,60}, (?:let'?s|try|use|can)\b",
           r"\b(?:break (?:it|this) down|one step at a time)\b"],
    "C2": [r"\b(?:don'?t|do not) (?:just )?(?:give|tell|show|write) me the (?:answer|solution|code|result)\b",
           r"\bquiz me\b", r"\b(?:give me |just )?(?:a|one) hint\b", r"\bguide me\b",
           r"\bask me (?:questions|a question)\b", r"\blet me (?:try|attempt|figure)\b",
           r"\bexplain [^.]{0,60}so (?:that )?i (?:can|understand|learn)\b"],
    "C3": [r"\b(?:assume|suppose) (?:that|we|the)\b", r"\bwithout using\b",
           r"\b(?:we|i) can(?:'?t|not) use\b", r"\bconstraints?\b", r"\breframe\b",
           r"\bthink (?:of|about) (?:it|this) as\b", r"\bonly (?:use|using)\b"],
    "C4": [r"\bhere'?s my (?:attempt|solution|code|answer|reasoning|approach|work)\b",
           r"\bi (?:think|believe|got|tried|reckon) [^.]{1,80}\bbecause\b",
           r"\bmy (?:answer|approach|reasoning|solution) (?:is|was)\b",
           r"\bis my (?:reasoning|answer|approach|solution|logic) (?:right|correct|sound)\b",
           r"\bwhere (?:does|did) my\b"],
    "C5": [r"\b(?:write|add|generate|create) (?:some )?(?:unit )?tests?\b", r"\bedge cases?\b",
           r"\btest (?:it|this) (?:with|on|against)\b", r"\bcompare (?:the|both|these|it|them)\b",
           r"\bsanity[- ]check\b", r"\b(?:derive|show the derivation|show your work|show the steps)\b"],
    "C6": [r"\bactually,? (?:i|we) (?:need|want|just need)\b",
           r"\b(?:my|the|our) (?:real )?(?:goal|priority|aim) is\b",
           r"\bmore (?:important|readable|maintainable) than\b",
           r"\blet'?s (?:aim|focus|settle) (?:for|on)\b", r"\bi(?:'ve)? changed my mind\b"],
    "O1": [r"\b(?:write|do|give me|make|create|generate|code) (?:me )?(?:the |a )?(?:whole|entire|full|complete)\b",
           r"\bjust (?:give|write|do|send) (?:me )?(?:it|the (?:answer|code|essay|solution|result))\b",
           r"\b(?:solve|answer|do) (?:this|these|the following|all)\b",
           r"\bdo my (?:homework|assignment|essay)\b"],
    "O2": [r"\A\s*(?:continue|go on|next|more|keep going|and\??|then\??|ok(?:ay)?|yes|go|proceed|next one|carry on)\s*[.!?]*\s*\Z",
           r"\A\s*(?:ok(?:ay)?|yes|sure|good),? (?:continue|next|go on|and then|now)\b[^.?!]{0,20}[.!?]*\s*\Z"],
    "O3": [r"\bmake it (?:longer|shorter|better|more \w+|less \w+|sound \w+)\b",
           r"\b(?:more|less) (?:formal|casual|detailed|concise|professional|academic)\b",
           r"\A\s*(?:longer|shorter|rewrite|rephrase|paraphrase|expand|simplify|elaborate)\b",
           r"\b(?:explain|add|write) more\b", r"\bin (?:\d+|fewer|more) words\b"],
    "O4": [r"\b(?:just |please )?fix (?:it|this|that|the code|the error)\b",
           r"\b(?:still )?(?:doesn'?t|does not|didn'?t|not) work(?:ing)?\b",
           r"\A\s*(?:wrong|no|incorrect|error|not working)[.!]*\s*\Z",
           r"\bsame (?:error|problem|issue)\b", r"\bgot (?:this|an|the following) error\b"],
    "O5": [r"\A\s*(?:thanks?|thank you|perfect|great|awesome|nice|good|cool)[!.,\s]+(?:now|next|also|and|can you)\b",
           r"\b(?:perfect|great|it works|works)[,!.]+\s*(?:now|next)\b"],
    "N2": [r"\b(?:unrelated|new question|another question|different question|change of topic)\b"],
    "N3": [r"\A\s*(?:hi|hello|hey|thanks?|thank you|ty|you'?re (?:great|awesome|the best)|good (?:morning|evening))[!.\s]*\Z"],
}
PATTERNS = {k: [re.compile(p, re.I) for p in v] for k, v in _P.items()}

FENCE = re.compile(r"\x60{3}.*?\x60{3}", re.S)
TRACEBACK = re.compile(r"Traceback \(most recent call last\)|^\s*File \".+\", line \d+|^\s*\w*(?:Error|Exception)\b[^\n]*:", re.M)
CODE_LINE = re.compile(r"^\s*(?:Traceback|File \"|at \S+\(|\w*(?:Error|Exception)\b|[{}\[\]();<>=#$]|\s{4,}\S)")


def _prose(text):
    """User-authored prose: fenced code and code/trace-like lines removed."""
    t = FENCE.sub(" ", text)
    return "\n".join(l for l in t.splitlines() if not CODE_LINE.match(l)).strip()


def code_turn(text):
    """Return the set of CMS sub-codes matched by one user turn."""
    text = text or ""
    prose = _prose(text)
    codes = {c for c, pats in PATTERNS.items() if any(p.search(prose) for p in pats)}
    if TRACEBACK.search(text) and len(prose.split()) < 8:
        codes.add("O4")                       # raw error pasted with no diagnosis
    pasted = bool(FENCE.search(text)) or len(prose) < 0.5 * max(len(text.strip()), 1)
    if not codes and (pasted or len(text) > 600):
        codes.add("N1")                       # context provision (code, data, documents)
    return codes or {"UNC"}


def reduce_state(codes):
    """Collapse a multi-label code set to one state with precedence C > M > O > N."""
    tops = {c[0] for c in codes if c != "UNC"}
    return next((t for t in PRECEDENCE if t in tops), "N")


def primary_subcode(codes):
    state = reduce_state(codes)
    subs = sorted(c for c in codes if c.startswith(state))
    return subs[0] if subs else "UNC"


# ---- assistant-turn features (Section 3.4); visible failure / self-contradiction are annotated, not lexical
HEDGE = re.compile(r"\b(?:might|may|possibly|perhaps|it(?:'s| is) possible|i(?:'m| am) not (?:sure|certain)|likely|unclear)\b", re.I)
SELF_VERIFY = re.compile(r"\b(?:let me (?:double[- ]check|verify|re-?check)|(?:you )?(?:should|may want to) (?:verify|test|double[- ]check)|please (?:verify|test|check))\b", re.I)
REFUSAL = re.compile(r"\b(?:i(?:'m| am) sorry,? but|i can(?:not|'t) (?:help|assist|provide|comply))\b", re.I)


def ai_features(text):
    text = text or ""
    return {"hedging": int(len(HEDGE.findall(text)) >= 2),
            "self_verify": int(bool(SELF_VERIFY.search(text))),
            "refusal": int(bool(REFUSAL.search(text[:400]))),
            "log_len": math.log1p(len(text.split()))}
