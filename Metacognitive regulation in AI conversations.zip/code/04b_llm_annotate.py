"""Step 4b - few-shot LLM annotation with the full codebook (any OpenAI-compatible endpoint).

Environment: CMS_LLM_MODEL, CMS_LLM_API_KEY, optional CMS_LLM_BASE_URL. Record model version + date.
"""
import argparse
import json
import os
import re

import pandas as pd
from openai import OpenAI

from cms.codebook import CODEBOOK
from cms.lexicon import reduce_state

SYSTEM = ("You are a trained annotator applying the Conversational Metacognitive Signatures codebook to ONE user turn "
          "of a human-AI conversation, read in the context of the preceding assistant turn.\n\nCodes:\n"
          + "\n".join(f"{k} {v[0]}: {v[1]}" for k, v in CODEBOOK.items())
          + "\n\nRules: code only what is evidenced in the text. A reported problem is M2 only if the user locates or "
            "characterises it; otherwise O4. Multiple codes allowed. Reply with JSON only: "
            '{"codes": ["..."], "primary": "..."}')


def main(a):
    client = OpenAI(base_url=os.getenv("CMS_LLM_BASE_URL"), api_key=os.getenv("CMS_LLM_API_KEY"))
    model = os.environ["CMS_LLM_MODEL"]
    system = SYSTEM
    if a.examples:
        ex = pd.read_csv(a.examples)
        system += "\n\nWorked examples:\n" + "\n".join(
            f"- AI: {str(r.prev_ai_text)[:200]!r} | USER: {str(r.user_text)[:300]!r} -> {r.subcode}" for r in ex.itertuples())
    df = pd.read_csv(a.gold).fillna({"prev_ai_text": "", "user_text": ""})
    out = []
    for r in df.itertuples():
        msg = f"PREVIOUS ASSISTANT TURN:\n{(r.prev_ai_text or '(none - first turn)')[-3000:]}\n\nUSER TURN:\n{r.user_text[:3000]}"
        resp = client.chat.completions.create(model=model, temperature=0,
                                              messages=[{"role": "system", "content": system},
                                                        {"role": "user", "content": msg}])
        m = re.search(r"\{.*\}", resp.choices[0].message.content or "", re.S)
        try:
            j = json.loads(m.group(0))
        except Exception:
            j = {"codes": ["UNC"], "primary": "UNC"}
        codes = set(j.get("codes") or [j.get("primary", "UNC")])
        out.append({"conv_id": r.conv_id, "turn_idx": r.turn_idx, "codes": "|".join(sorted(codes)),
                    "subcode": j.get("primary", "UNC"), "state": reduce_state(codes)})
    pd.DataFrame(out).to_csv(a.out, index=False)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--gold", required=True)
    p.add_argument("--examples", default=None, help="CSV of worked examples: prev_ai_text, user_text, subcode")
    p.add_argument("--out", default="data/labels_llm.csv")
    main(p.parse_args())
