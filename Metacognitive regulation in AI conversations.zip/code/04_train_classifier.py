"""Step 4 - fine-tune DeBERTa-v3 on gold labels (Section 4.4) and label the full sample.

--context  pairs each user turn with the (truncated) preceding assistant turn.
"""
import argparse

import krippendorff
import numpy as np
import pandas as pd
from datasets import Dataset
from sklearn.metrics import classification_report, f1_score
from sklearn.model_selection import GroupShuffleSplit
from transformers import (AutoModelForSequenceClassification, AutoTokenizer,
                          DataCollatorWithPadding, Trainer, TrainingArguments)

MODEL = "microsoft/deberta-v3-base"
REG = {"M", "C"}


def encoder(tok, context):
    def enc(b):
        users = [str(t)[:2000] for t in b["user_text"]]
        if context:
            prev = [str(t)[-1500:] for t in b["prev_ai_text"]]
            return tok(users, prev, truncation="longest_first", max_length=384)
        return tok(users, truncation=True, max_length=256)
    return enc


def evaluate(y_true, y_pred):
    t_top, p_top = [y[0] for y in y_true], [y[0] for y in y_pred]
    cats = {c: i for i, c in enumerate(sorted(set(t_top) | set(p_top)))}
    reg = [i for i, y in enumerate(t_top) if y in REG]
    return {"macro_f1_top": f1_score(t_top, p_top, average="macro"),
            "macro_f1_sub": f1_score(y_true, y_pred, average="macro"),
            "alpha_top": krippendorff.alpha(reliability_data=np.array([[cats[x] for x in t_top], [cats[x] for x in p_top]], float),
                                            level_of_measurement="nominal"),
            "regulation_recall": np.mean([p_top[i] in REG for i in reg]) if reg else float("nan")}


def main(a):
    df = pd.read_csv(a.gold).fillna({"prev_ai_text": "", "user_text": ""})
    labels = sorted(df["subcode"].unique())
    l2i = {l: i for i, l in enumerate(labels)}
    df["label"] = df["subcode"].map(l2i)
    tr, te = next(GroupShuffleSplit(n_splits=1, test_size=a.test_size, random_state=2026).split(df, groups=df.conv_id))

    tok = AutoTokenizer.from_pretrained(MODEL)
    enc = encoder(tok, a.context)
    cols = ["user_text", "prev_ai_text", "label"]
    ds_tr = Dataset.from_pandas(df.iloc[tr][cols], preserve_index=False).map(enc, batched=True)
    ds_te = Dataset.from_pandas(df.iloc[te][cols], preserve_index=False).map(enc, batched=True)

    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL, num_labels=len(labels), id2label=dict(enumerate(labels)), label2id=l2i)
    args = TrainingArguments(output_dir=a.out, num_train_epochs=a.epochs, learning_rate=2e-5,
                             per_device_train_batch_size=16, per_device_eval_batch_size=32,
                             weight_decay=0.01, warmup_ratio=0.1, save_strategy="no",
                             report_to=[], seed=2026)
    trainer = Trainer(model=model, args=args, train_dataset=ds_tr,
                      data_collator=DataCollatorWithPadding(tok), tokenizer=tok)
    trainer.train()

    pred = trainer.predict(ds_te).predictions.argmax(-1)
    y_true, y_pred = df.iloc[te]["subcode"].tolist(), [labels[i] for i in pred]
    print(classification_report(y_true, y_pred, zero_division=0))
    print({k: round(float(v), 3) for k, v in evaluate(y_true, y_pred).items()})
    trainer.save_model(a.out)

    if a.predict:   # label the full sample with the trained model
        full = pd.read_parquet(a.predict).fillna({"prev_ai_text": "", "user_text": ""})
        ds = Dataset.from_pandas(full[["user_text", "prev_ai_text"]], preserve_index=False).map(enc, batched=True)
        full["subcode"] = [labels[i] for i in trainer.predict(ds).predictions.argmax(-1)]
        full["state"] = full["subcode"].str[0]
        from cms.lexicon import ai_features
        feats = pd.DataFrame(full["next_ai_text"].map(ai_features).tolist(), index=full.index).add_prefix("ai_")
        pd.concat([full, feats], axis=1).drop(columns=["user_text", "prev_ai_text", "next_ai_text"]).to_csv(a.pred_out, index=False)
        print(f"labels -> {a.pred_out}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--gold", required=True, help="adjudicated gold CSV: conv_id, turn_idx, user_text, prev_ai_text, subcode")
    p.add_argument("--context", action="store_true")
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--test-size", type=float, default=0.3)
    p.add_argument("--out", default="models/cms-deberta")
    p.add_argument("--predict", default=None, help="turns.parquet to label after training")
    p.add_argument("--pred-out", default="data/labels_model.csv")
    main(p.parse_args())
